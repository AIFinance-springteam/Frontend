export const routePaths = {
<<<<<<< Updated upstream
  tripHome: (tripId = 'busan-2508') => `/trips/${tripId}`,
  receiptDetail: (tripId: string, receiptId: string) =>
    `/trips/${tripId}/receipts/${receiptId}`,
  receiptSplit: (receiptId = 'cu') => `/receipts/${receiptId}/split`,
  settlementResult: (tripId = 'busan-2508') => `/trips/${tripId}/settlement`,
}
=======
  tripHome: (tripId = "tripId") => `/trips/${tripId}`,
  receiptSplit: (tripId: string, receiptId: string) => `/trips/${tripId}/receipts/${receiptId}/split`,
};
>>>>>>> Stashed changes
